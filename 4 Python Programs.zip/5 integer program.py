# input is string by default
# convert it to a float
# so you can use >=
num1 = float(input("Enter a number: "))
num2 = float(input("Enter a number: "))
num3 = float(input("Enter a number: "))
num4 = float(input("Enter a number: "))
num5 = float(input("Enter a number: "))

# if first number is greater than second and third
# first number is maximum
if num1 >= num2 and num1 >= num3:
    print(num1)
    
# same thing for second number
elif num2 >= num1 and num2 >= num3:
    print(num2)

# same thing for fourth number
elif num4 >= num1 and num4 >= num3:
    print(num4)

# same thing for fifth number
elif num5 >= num1 and num5 >= num3:
    print(num5)

# if first two numbers are not maximum
# the third or fourth or fifth must be
else:
    print(num3)or print(num4)or print(num5)
    
