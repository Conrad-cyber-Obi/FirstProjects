def main():

    print("Enter a number between 1 and 50000")

    i = input()  # this is a string

    # ALWAYS validate user input!
    try:
        n = int(i)  # ValueError if it's not a valid int
        if not (1 < n < 50000):
            raise UserWarning
    except ValueError:
        print("that's not a valid number")
    except UserWarning:
        print("number must be between 1 and 50000!")
    else:
        print("{}".format(n)) # -> ...

    restart=input("Do you want to start again").lower()
    if restart == "yes":
        main()

    else:
        exit()
#Where the code starts
main()

    
    
