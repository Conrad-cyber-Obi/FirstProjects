celsiusTemperature = float( input( " Please enter a temperature in Celcius: " ) )

fahrenheitTemperature = ( ( 1.8 ) * celsiusTemperature ) + 32

print( str( celsiusTemperature ) + " Degrees Celsius Converts to Degrees Fahrenheit " + \
       str( fahrenheitTemperature ) ) 

# Celsius to Fahrenheit Temperature Converter

# Write a Python program to peform the task of temperature conversion from
# Celsius to Fahrenheit. Note that given C as the degree of temperature in
# In Celsius, the corresponding degree F in Fahrenheit equals 1.8*C + 32.0.
# For example 50 degree Celsius should be 122 degree Fahrenheit.

# F = (1.8)C + 32

# Program will convert Celsius to Fahrenheit 
