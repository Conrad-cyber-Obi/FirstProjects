# current balance is

# B = P(1+ r/n)^(yn)

# where P is the starting principal

# r is the annual interest rate (number between 0 and 1)

# y is the number of years invested

# n is the number of compounding periods per year

# is our case n is 1
def balance(P, r, y):
    # for n = 1 formula is B = P(1+r)^y
    return P*(1 + r)**y

# In Order for program to work you must type balance first
# then enter your principle, rate, year enclosed in parenthesis
balance(500, 0.06, 10) # returns 895.4238
